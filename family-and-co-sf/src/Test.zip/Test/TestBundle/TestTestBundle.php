<?php

namespace Test\TestBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TestTestBundle extends Bundle
{
}
