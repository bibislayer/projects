<?php

namespace Test\TestBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Book
 */
class Book
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $isbn;

    /**
     * @var string
     */
    private $title;

    /**
     * @var string
     */
    private $description;

    /**
     * @var array
     */
    private $cover;

    /**
     * @var integer
     */
    private $year_publication;

    /**
     * @var integer
     */
    private $nb_page;

    /**
     * @var \Doctrine\Common\Collections\Collection
     */
    private $authors;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->authors = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set isbn
     *
     * @param string $isbn
     * @return Book
     */
    public function setIsbn($isbn)
    {
        $this->isbn = $isbn;

        return $this;
    }

    /**
     * Get isbn
     *
     * @return string 
     */
    public function getIsbn()
    {
        return $this->isbn;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Book
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Book
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set cover
     *
     * @param array $cover
     * @return Book
     */
    public function setCover($cover)
    {
        $this->cover = $cover;

        return $this;
    }

    /**
     * Get cover
     *
     * @return array 
     */
    public function getCover()
    {
        return $this->cover;
    }

    /**
     * Set year_publication
     *
     * @param integer $yearPublication
     * @return Book
     */
    public function setYearPublication($yearPublication)
    {
        $this->year_publication = $yearPublication;

        return $this;
    }

    /**
     * Get year_publication
     *
     * @return integer 
     */
    public function getYearPublication()
    {
        return $this->year_publication;
    }

    /**
     * Set nb_page
     *
     * @param integer $nbPage
     * @return Book
     */
    public function setNbPage($nbPage)
    {
        $this->nb_page = $nbPage;

        return $this;
    }

    /**
     * Get nb_page
     *
     * @return integer 
     */
    public function getNbPage()
    {
        return $this->nb_page;
    }

    /**
     * Add authors
     *
     * @param \Test\TestBundle\Entity\Author $authors
     * @return Book
     */
    public function addAuthor(\Test\TestBundle\Entity\Author $authors)
    {
        $this->authors[] = $authors;

        return $this;
    }

    /**
     * Remove authors
     *
     * @param \Test\TestBundle\Entity\Author $authors
     */
    public function removeAuthor(\Test\TestBundle\Entity\Author $authors)
    {
        $this->authors->removeElement($authors);
    }

    /**
     * Get authors
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getAuthors()
    {
        return $this->authors;
    }
    /**
     * @var integer
     */
    private $publish_date;

    /**
     * @var integer
     */
    private $number_of_pages;


    /**
     * Set publish_date
     *
     * @param integer $publishDate
     * @return Book
     */
    public function setPublishDate($publishDate)
    {
        $this->publish_date = $publishDate;

        return $this;
    }

    /**
     * Get publish_date
     *
     * @return integer 
     */
    public function getPublishDate()
    {
        return $this->publish_date;
    }

    /**
     * Set number_of_pages
     *
     * @param integer $numberOfPages
     * @return Book
     */
    public function setNumberOfPages($numberOfPages)
    {
        $this->number_of_pages = $numberOfPages;

        return $this;
    }

    /**
     * Get number_of_pages
     *
     * @return integer 
     */
    public function getNumberOfPages()
    {
        return $this->number_of_pages;
    }
}
