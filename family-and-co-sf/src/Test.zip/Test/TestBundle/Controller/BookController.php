<?php

namespace Test\TestBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Test\TestBundle\Entity\Book;
use Test\TestBundle\Entity\Author;

class BookController extends Controller
{
    public function listAction($name)
    {
        return $this->render('TestTestBundle:Book:list.html.twig', array('name' => $name));
    }
    public function listAuthorAction()
    {
    	$em = $this->getDoctrine()->getManager();
    	$authors = $em->getRepository('TestTestBundle:Author')->findAll();
        return $this->render('TestTestBundle:Autor:list.html.twig', array('authors' => $authors));
    }
    public function indexAction()
    {
    	$em = $this->getDoctrine()->getManager();
    	$books = $em->getRepository('TestTestBundle:Book')->findAll();

        return $this->render('TestTestBundle:Book:index.html.twig', array('books' => $books));
    }
    public function formAction()
    {
        return $this->render('TestTestBundle:Book:form.html.twig');
    }
    public function searchBookAction($isbn)
    {
        return $this->render('TestTestBundle:Book:form.html.twig');
    }
    public function createAction()
    {
    	$request = $this->getRequest();
    	if ($request->getMethod() == 'POST') {
    		$ch = curl_init("https://openlibrary.org/api/books?bibkeys=ISBN:".$this->get('request')->request->get('isbn')."&format=json&jscmd=details&prettyprint=true");
			curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 0);
			$result = curl_exec($ch);
			$r = json_decode($result, true);
			$apiBook = $r["ISBN:".$this->get('request')->request->get('isbn')]['details'];
			curl_close($ch);
			$apiBook['isbn'] = $this->get('request')->request->get('isbn');
        	return $this->render('TestTestBundle:Book:form.html.twig', array('book' => $apiBook));
    	}
    }
    public function saveAction()
    {
    	$request = $this->getRequest();
    	if ($request->getMethod() == 'POST') {
    		$postRquest = $this->get('request')->request;
    		$em = $this->getDoctrine()->getManager();
			$book = new Book();
			$exist = $em->getRepository('TestTestBundle:Book')->findOneByIsbn($postRquest->get('isbn'));
			if($exist)
				$book = $exist;
			$book->setIsbn($postRquest->get('isbn'));
			$book->setTitle($postRquest->get('title'));
			$book->setDescription($postRquest->get('description'));
			$book->setCover($postRquest->get('covers'));
			$book->setPublishDate($postRquest->get('publish_date'));
			$book->setNumberOfPages($postRquest->get('number_of_pages'));
			$authors = $postRquest->get('authors');
			for($i=0;$i<count($authors);$i++){
				$author = new Author();
				$author->setName($authors[$i]);
				$author->addBook($book);
				$em->persist($author);
			}
			$em->persist($book);  
		    $em->flush();

        	return $this->redirect($this->generateUrl('test_book_index'));
    	}
    }
    public function editAction($isbn)
    {
		$em = $this->getDoctrine()->getManager();
    	$book = $em->getRepository('TestTestBundle:Book')->findOneByIsbn($isbn);
        return $this->render('TestTestBundle:Book:form.html.twig', array('book' => $book));
    }
    public function removeAction($isbn)
    {
    	$em = $this->getDoctrine()->getManager();
    	$book = $em->getRepository('TestTestBundle:Book')->findOneByIsbn($isbn);
    	$em->remove($book);  
		$em->flush();
        return $this->redirect($this->generateUrl('test_book_index'));
    }

    public function authorRemoveAction($id)
    {
    	$em = $this->getDoctrine()->getManager();
    	$author = $em->getRepository('TestTestBundle:Author')->findOneById($id);
    	foreach ($author->getBooks() as $book) {
    		$em->remove($book);
    	}
    	$em->remove($author);  
		$em->flush();
        return $this->redirect($this->generateUrl('test_author_list'));
    }
}
