<?php

namespace Test\TestBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DefaultController extends Controller
{
    public function helloAction($name)
    {
        return $this->render('TestTestBundle:Default:hello.html.twig', array('name' => $name));
    }
    public function indexAction()
    {
        return $this->render('TestTestBundle:Default:index.html.twig');
    }
}
